package thlinh1.slide04.exercise02;

public abstract class Parent {
    public void message() {
        System.out.println("===> This is parent class");
    }
    public abstract void messageAbstract() ;

}
