package thlinh1.slide04.exercise01;

public class Student {
    public String name;

    public Student() {
        this.name = "Unknown";
    }

    public Student(String name) {
        this.name = name;
    }
}
