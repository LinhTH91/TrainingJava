package thlinh1.slide03.exercise03;

public class Employee {
    public String name;
    public int yearOfJoining;
    public double salary;
    public String address;
    public Employee() {

    }

}
