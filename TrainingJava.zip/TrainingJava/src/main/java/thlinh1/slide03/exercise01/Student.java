package thlinh1.slide03.exercise01;

public class Student {
    public int rollNo;
    public String name;

    public Student() {
        this.rollNo = 2;
        this.name = "John";
    }

    public Student(int rollNo, String name) {
        this.rollNo = rollNo;
        this.name = name;
    }
}
